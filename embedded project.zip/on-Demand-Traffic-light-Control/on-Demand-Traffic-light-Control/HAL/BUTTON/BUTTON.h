/*
 * BUTTON.h
 *
 * Created: 11/8/2022 3:44:49 PM
 *  Author: Technology
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_


void led_on(port,ledpin)


#endif /* BUTTON_H_ */