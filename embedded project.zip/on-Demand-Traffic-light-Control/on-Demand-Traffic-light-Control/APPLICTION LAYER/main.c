/*
 * on-Demand-Traffic-light-Control.c
 *
 * Created: 10/31/2022 8:50:25 PM
 * Author : Technology
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

